pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    loadMapStuff();
  }, 2000);
  
  function loadMapStuff() {
    const light = pc.app.root.findByName("Light");
    
    if (pc.currentMap === "Xibalba") {
      light.enabled = true;
    } else {
      light.enabled = false;
    }
  }
});
