//Code is taken from the original creator named NeXi2k

pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    gameplayStuff();
  }, 2000);
});

pc.app.on("Player:Leave", () => {
  window.location.replace("https://venge.io");
});

setTimeout(() => {
  if(SocialMode == 1) {
    if(document.location.href.includes("social")) {
    }
    else {
      document.location.href = "https://social.venge.io/"
    }
  }
}, 1000)

pc.app.on("Game:PlayerJoin", () => {
  setTimeout(() => {
    var LiliumDefault = pc.app.assets.getAssetById(29694230).resources[0];
    var ShinDefault = pc.app.assets.getAssetById(32463625).resources[0];
    var EchoDefault = pc.app.assets.getAssetById(37198907).resources[0];
    var KuluDefault = pc.app.assets.getAssetById(55399331).resources[0];
    for (
      let i = 0;
      i <=
      pc.app.root.findByName("Game").findByName("PlayerHolder").children
        .length -
        1;
      i++
    ) {
      if (
        pc.app.root.findByName("PlayerHolder").children[i].script.enemy
          .heroSkin == "Default"
      ) {
        pc.app.root
          .findByName("PlayerHolder")
          .children[i].findByName("ModelHolder")
          .findByName("Lilium").model.meshInstances[0].material.diffuseMap =
          LiliumDefault;
        pc.app.root
          .findByName("PlayerHolder")
          .children[i].findByName("ModelHolder")
          .findByName("Lilium")
          .model.meshInstances[0].material.update();
        pc.app.root
          .findByName("PlayerHolder")
          .children[i].findByName("ModelHolder")
          .findByName("Shin").model.meshInstances[0].material.diffuseMap =
          ShinDefault;
        pc.app.root
          .findByName("PlayerHolder")
          .children[i].findByName("ModelHolder")
          .findByName("Shin")
          .model.meshInstances[0].material.update();
        if (
          pc.app.root.findByName("PlayerHolder").children[i].script.enemy
            .hero == "Echo"
        ) {
          console.log("Found a Echo in the game");
          pc.app.root
            .findByName("PlayerHolder")
            .children[i].findByName("ModelHolder")
            .findByName("Echo").model.meshInstances[0].material.diffuseMap =
            EchoDefault;
          pc.app.root
            .findByName("PlayerHolder")
            .children[i].findByName("ModelHolder")
            .findByName("Echo")
            .model.meshInstances[0].material.update();
        } else if (
          pc.app.root.findByName("PlayerHolder").children[i].script.enemy
            .hero == "Kulu"
        ) {
          console.log("Found a Kulu in the game");
          pc.app.root
            .findByName("PlayerHolder")
            .children[i].findByName("ModelHolder")
            .findByName("Kulu").model.meshInstances[0].material.diffuseMap =
            KuluDefault;
          pc.app.root
            .findByName("PlayerHolder")
            .children[i].findByName("ModelHolder")
            .findByName("Kulu")
            .model.meshInstances[0].material.update();
        }
      }
    }
  }, 2000);
});

function gameplayStuff() {

  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-1"
  ].volume = 0.5;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-2"
  ].volume = 0.5;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Jump-1"
  ].volume = 0.6;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Jump-2"
  ].volume = 0.6;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-2"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-3"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Death-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Echo-Jump-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Echo-Jump-2"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-1"
  ].volume = 0.8;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-2"
  ].volume = 0.8;
  
  pc.app.root
      .findByName("Game")
      .findByName("UnlockItemReward").enabled = false;
  }