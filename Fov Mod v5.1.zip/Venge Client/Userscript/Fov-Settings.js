// These are settings for FOV Mod

removelight = 1; //(Default: 1) Removes Light from all maps except Xibalba
hidehands = 0; //(Default: 0) Hides your hands
hideads = 0; //(Default: 0) Hides the weapon when aiming down sights (ADS)
endmessage = 0; //(Default: 0) Sends a message at the end of the game
endmessage_text = "Follow Me - https://social.venge.io/?profile#Moroxi"; //Set the end message text