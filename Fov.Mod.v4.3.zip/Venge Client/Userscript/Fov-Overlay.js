//Code is taken from the original creator named NeXi2k

pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    overlayStuff();
  }, 2000);
});

  pc.app.scripts._list[0].prototype.setKeyboard = function () {
    return (
      !this.isFrozen &&
      !this.player.isDeath &&
      !pc.isFinished &&
      !this.locked &&
      "INPUT" != document.activeElement.tagName &&
      (this.jumpingTime + this.jumpLandTime < this.timestamp &&
        this.currentHeight < this.nearGround &&
        ((this.isForward = !1),
        (this.isBackward = !1),
        (this.isLeft = !1),
        (this.isRight = !1)),
      (this.app.keyboard.isPressed(pc.KEY_UP) ||
        this.app.keyboard.isPressed(pc.KEY_W) ||
        this.isMobileForward) &&
        (this.isForward = !0),
      (this.app.keyboard.isPressed(pc.KEY_DOWN) ||
        this.app.keyboard.isPressed(pc.KEY_S) ||
        this.isMobileBackward) &&
        (this.isBackward = !0),
      (this.app.keyboard.isPressed(pc.KEY_LEFT) ||
        this.app.keyboard.isPressed(pc.KEY_A) ||
        this.isMobileLeft) &&
        (this.isLeft = !0),
      (this.app.keyboard.isPressed(pc.KEY_RIGHT) ||
        this.app.keyboard.isPressed(pc.KEY_D) ||
        this.isMobileRight) &&
        (this.isRight = !0),
      this.app.keyboard.wasPressed(pc.KEY_SPACE) && this.jump(),
      this.app.keyboard.wasPressed(pc.KEY_R) && this.reload(),
      this.app.keyboard.wasPressed(pc.KEY_F) && this.triggerKeyF(),
      this.app.keyboard.wasPressed(pc.KEY_E) && this.triggerKeyE(),
      this.app.keyboard.wasPressed(pc.KEY_V) && this.player.spray(),
      this.app.keyboard.wasPressed(pc.KEY_X) &&
        ((this.leftMouse = !0), (this.isMouseReleased = !0)),
      this.app.keyboard.wasReleased(pc.KEY_X) && (this.leftMouse = !1),
      this.app.keyboard.wasPressed(pc.KEY_L) &&
        (this.app.fire("Mouse:Lock"), this.app.fire("Overlay:Pause", !1)),
      this.app.keyboard.wasPressed(pc.KEY_M),
      this.app.keyboard.wasPressed(pc.KEY_J) && this.inspect(),
      this.app.keyboard.wasPressed(pc.KEY_SHIFT) && (this.isFocusing = !0),
      this.app.keyboard.wasPressed(pc.KEY_F6) && toggleOverlay(),
      this.app.keyboard.wasPressed(pc.KEY_M) && openTeamMenu(),
      void (
        this.app.keyboard.wasReleased(pc.KEY_SHIFT) && (this.isFocusing = !1)
      ))
    );
  };

function toggleOverlay() {
  if (pc.settings.hideUIElements == 0) {
    var t = pc.app.root.findByName("Overlay").findByTag("Gameplay");
    for (var e in t) {
      var i = t[e];
      i && (i.enabled = !1);
    }
    pc.app.root.findByName("Stats").enabled = false;
    pc.settings.hideUIElements = true;
  } else if (pc.settings.hideUIElements == 1) {
    var t = pc.app.root.findByName("Overlay").findByTag("Gameplay");
    for (var e in t) {
      var i = t[e];
      i && (i.enabled = !0);
    }
    pc.app.root.findByName("Stats").enabled = true;
    pc.settings.hideUIElements = false;
  }
}

function openTeamMenu() {
  document.exitPointerLock();
  setTimeout(() => {
    pc.app.fire("Overlay:Pause", !0), pc.app.fire("View:Pause", "Team");
  }, 1);
}

function overlayStuff() {
  pc.app.root
    .findByName("Overlay")
    .findByName("Continue").parent.script.button.fireFunction = "Player:Leave";
}