//Code is taken from the original creator named NeXi2k

window.EnableAdCrate = 0;
window.MatchEndingMusic = 1;