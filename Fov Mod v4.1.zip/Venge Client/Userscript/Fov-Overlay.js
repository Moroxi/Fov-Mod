//Code is taken from the original creator named NeXi2k

pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    overlayStuff();
  }, 2000);
});

setTimeout(() => {
  pc.app.scripts.list()[10].prototype.setDeath = function (t, e) {
    if (
      ((this.killedBy = t),
      (this.isDeath = !0),
      this.deathCount++,
      this.movement.death(),
      (this.gliderEntity.enabled = !1),
      (this.characterHolder.enabled = !0),
      this.characterEntity.setLocalEulerAngles(0, this.movement.lookX, 0),
      setTimeout(
        function (t) {
          t.movement.lookEntity.enabled = !1;
        },
        100,
        this
      ),
      this.characterEntity.setLocalPosition(0, -2.15, 0),
      (this.characterEntity.animation.speed = 1),
      this.app.fire("CustomText:KillMessage", ""),
      "Drown" == e
        ? (this.characterEntity.animation.play("Floating"),
          (this.characterEntity.animation.speed = 3),
          (this.characterEntity.animation.loop = !0),
          this.entity.sound.play("Splash"),
          this.characterEntity.setLocalPosition(0, -3.5, 0),
          this.characterEntity
            .tween(this.characterEntity.getLocalPosition())
            .to(
              {
                x: 0,
                y: -6.5,
                z: 0,
              },
              2,
              pc.Linear
            )
            .start())
        : (this.characterEntity.animation.play("Death"),
          (this.characterEntity.animation.loop = !1)),
      (this.characterCamera.script.blackWhite.enabled = !0),
      this.characterCamera.setLocalPosition(0, 1.215, -0.115),
      this.characterCamera
        .tween(this.characterCamera.getLocalPosition())
        .to(
          {
            x: 0,
            y: 3.015,
            z: 7,
          },
          1,
          pc.SineOut
        )
        .start(),
      this.characterCamera.setLocalEulerAngles(0, 0, 0),
      this.characterCamera
        .tween(this.characterCamera.getLocalEulerAngles())
        .rotate(
          {
            x: -18,
            y: 0,
            z: 0,
          },
          0.7,
          pc.BackOut
        )
        .start(),
      this.interface.hideGameplay(),
      this.killedBy && this.killedBy != this.entity)
    ) {
      var i = Utils.displayUsername(this.killedBy.script.enemy.username);
      this.app.fire(
        "Overlay:Status",
        'Rekt by [color="#00FFFF"]' + i + "[/color]"
      ),
        this.app.fire(
          "CustomText:KillMessage",
          this.killedBy.script.enemy.killMessage
        );
    }
    this.app.fire("Player:StopSpeaking", !0), this.showCircularMenu();
  };

  pc.app.scripts._list[0].prototype.setKeyboard = function () {
    return (
      !this.isFrozen &&
      !this.player.isDeath &&
      !pc.isFinished &&
      !this.locked &&
      "INPUT" != document.activeElement.tagName &&
      (this.jumpingTime + this.jumpLandTime < this.timestamp &&
        this.currentHeight < this.nearGround &&
        ((this.isForward = !1),
        (this.isBackward = !1),
        (this.isLeft = !1),
        (this.isRight = !1)),
      (this.app.keyboard.isPressed(pc.KEY_UP) ||
        this.app.keyboard.isPressed(pc.KEY_W) ||
        this.isMobileForward) &&
        (this.isForward = !0),
      (this.app.keyboard.isPressed(pc.KEY_DOWN) ||
        this.app.keyboard.isPressed(pc.KEY_S) ||
        this.isMobileBackward) &&
        (this.isBackward = !0),
      (this.app.keyboard.isPressed(pc.KEY_LEFT) ||
        this.app.keyboard.isPressed(pc.KEY_A) ||
        this.isMobileLeft) &&
        (this.isLeft = !0),
      (this.app.keyboard.isPressed(pc.KEY_RIGHT) ||
        this.app.keyboard.isPressed(pc.KEY_D) ||
        this.isMobileRight) &&
        (this.isRight = !0),
      this.app.keyboard.wasPressed(pc.KEY_SPACE) && this.jump(),
      this.app.keyboard.wasPressed(pc.KEY_R) && this.reload(),
      this.app.keyboard.wasPressed(pc.KEY_F) && this.triggerKeyF(),
      this.app.keyboard.wasPressed(pc.KEY_E) && this.triggerKeyE(),
      this.app.keyboard.wasPressed(pc.KEY_V) && this.player.spray(),
      this.app.keyboard.wasPressed(pc.KEY_X) &&
        ((this.leftMouse = !0), (this.isMouseReleased = !0)),
      this.app.keyboard.wasReleased(pc.KEY_X) && (this.leftMouse = !1),
      this.app.keyboard.wasPressed(pc.KEY_L) &&
        (this.app.fire("Mouse:Lock"), this.app.fire("Overlay:Pause", !1)),
      this.app.keyboard.wasPressed(pc.KEY_M),
      this.app.keyboard.wasPressed(pc.KEY_J) && this.inspect(),
      this.app.keyboard.wasPressed(pc.KEY_SHIFT) && (this.isFocusing = !0),
      this.app.keyboard.wasPressed(pc.KEY_F6) && toggleOverlay(),
      this.app.keyboard.wasPressed(pc.KEY_M) && openTeamMenu(),
      void (
        this.app.keyboard.wasReleased(pc.KEY_SHIFT) && (this.isFocusing = !1)
      ))
    );
  };

  pc.app.scripts._list[2].prototype.showPrepare = function () {
    (this.prepareEntity.enabled = !0),
      this.prepareEntity.setLocalScale(0.5, 0.5, 0.5),
      this.prepareEntity
        .tween(this.prepareEntity.getLocalScale())
        .to(
          {
            x: 1.5,
            y: 1.5,
            z: 1.5,
          },
          0.1,
          pc.SineOut
        )
        .start();
    if (pc.app.root.findByName("LMG").enabled == true) {
      this.reloadingTime = 3.3;
    } else {
      this.reloadingTime = 2.0;
    }
    if (pc.app.root.findByName("LMG").enabled == true) {
      setTimeout(() => {
        pc.app.root.findByName("ReloadingTime").parent.enabled = false;
      }, 3300);
    } else {
      setTimeout(() => {
        pc.app.root.findByName("ReloadingTime").parent.enabled = false;
      }, 2000);
    }
  };
}, 2000);

function toggleOverlay() {
  if (pc.settings.hideUIElements == 0) {
    var t = pc.app.root.findByName("Overlay").findByTag("Gameplay");
    for (var e in t) {
      var i = t[e];
      i && (i.enabled = !1);
    }
    pc.app.root.findByName("Stats").enabled = false;
    pc.settings.hideUIElements = true;
  } else if (pc.settings.hideUIElements == 1) {
    var t = pc.app.root.findByName("Overlay").findByTag("Gameplay");
    for (var e in t) {
      var i = t[e];
      i && (i.enabled = !0);
    }
    pc.app.root.findByName("Stats").enabled = true;
    pc.settings.hideUIElements = false;
  }
}

function openTeamMenu() {
  document.exitPointerLock();
  setTimeout(() => {
    pc.app.fire("Overlay:Pause", !0), pc.app.fire("View:Pause", "Team");
  }, 1);
}

function overlayStuff() {
  pc.app.root
    .findByName("Overlay")
    .findByName("Continue").parent.script.button.fireFunction = "Player:Leave";

  pc.app.root.findByName("BarBackground").enabled = false;
  pc.app.root.findByName("Value").children[0].element.color = {
    r: 1,
    g: 0,
    b: 0,
    a: 1,
  };
  pc.app.root.findByName(
    "ObjectiveHolder"
  ).children[1].children[0].element.opacity = 0;
  pc.app.root.findByName(
    "ObjectiveHolder"
  ).children[1].children[1].element.color = { r: 0, b: 1, g: 1, a: 1 };
  pc.app.root.findByName(
    "ObjectiveHolder"
  ).children[1].children[1].element.width = 19;
  pc.app.root.findByName(
    "ObjectiveHolder"
  ).children[1].children[1].element.height = 19;
  pc.app.root.findByName("ReloadingTime").parent.children[0].element.color = {
    r: 0,
    b: 1,
    g: 1,
    a: 1,
  };
  pc.app.root.findByName("Container").element.opacity = 0;
  pc.app.root.findByName("Task").findByName("Background").element.color = {
    r: 0,
    b: 0.6,
    g: 0.3,
    a: 1,
  };
  pc.app.root.findByName("Task").findByName("Background").element.opacity = 0.3;
  pc.app.root.findByName("Task").findByName("Title").element.opacity = 0;
  pc.app.root
    .findByName("Task")
    .findByName("Title")
    .findByName("Image").element.opacity = 0;
  pc.app.root
    .findByName("Task")
    .findByName("Title")
    .findByName("Label").element.opacity = 0;
  pc.app.root.findByName("Task").children[2].element.opacity = 1;
  pc.app.root.findByName("Task").children[3].element.color = {
    r: 0,
    b: 1,
    g: 1,
    a: 1,
  };
  pc.app.root.findByName("Achievement").children[0].enabled = false;
  pc.app.root.findByName("Achievement").children[1].enabled = false;
  pc.app.root.findByName("Achievement").children[2].enabled = false;
  pc.app.root.findByName("Achievement").children[3].element.color = {
    r: 0,
    b: 0.6,
    g: 0.6,
    a: 1,
  };
  pc.app.root.findByName("Achievement").children[3].element.opacity = 1;
  pc.app.root.findByName("Achievement").children[7].enabled = false;
}
