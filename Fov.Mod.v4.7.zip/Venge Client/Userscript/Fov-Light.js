pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    pc.app.root.findByName("Light").enabled = false
  }, 2000);
});
