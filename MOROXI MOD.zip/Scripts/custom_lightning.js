document.addEventListener("DOMContentLoaded", () => {
  pc.app.on("Map:Loaded", () => {
    try {
      pc.app.root.findByName("MapHolder").children[0].light.color = { r: 0, g: 0, b: 0, a: 1 };
    } catch (error) {
      console.log(error);
    }
  })
})