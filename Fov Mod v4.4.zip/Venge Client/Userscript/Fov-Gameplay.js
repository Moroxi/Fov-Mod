//Code is taken from the original creator named NeXi2k

pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    gameplayStuff();
  }, 2000);
});

pc.app.on("Player:Leave", () => {
  window.location.replace("https://venge.io");
});

setTimeout(() => {

    pc.app.scripts.list()[7].prototype.onHeadshot = function (t, e) {
      this.app.fire("DealtDamage:Trigger", e, t, !0),
        this.screenEntity.sound.play("Headshot"),
        (this.hitmarkerEntity.element.opacity = 1),
        this.hitmarkerEntity.setLocalScale(0.3, 0.3, 0.3),
        this.hitmarkerEntity
          .tween(this.hitmarkerEntity.getLocalScale())
          .to(
            {
              x: 1.2,
              y: 1.2,
              z: 1.2,
            },
            0.25,
            pc.BackOut
          )
          .start(),
        (this.lastHeadshot = Date.now());
    };
}, 1000);

setInterval(() => {
  pc.app.root.findByName("TimesAndScore").children[4].children[1].element.text = pc.app.root.findByName("ObjectiveTime").parent.children[1].element.text
  var ms = pc.app.root.findByName("ObjectiveTime").parent.children[1].element.text
  window.split = ms.split(':')
  var strToNum = parseInt(split[1])
  if(strToNum >= 30) {
      pc.app.root.findByName("ObjectiveTime").parent.children[4].setLocalPosition(0, -59.82, 0)
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[0].element.opacity = 1
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[1].element.opacity = 1
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[1].element.text = strToNum - 30
      pc.app.root.findByName("ObjectiveHolder").children[1].children[2].element.text = strToNum - 30
  }
  else if (strToNum <= 30) {
      pc.app.root.findByName("ObjectiveTime").parent.children[4].setLocalPosition(0, -59.82, 0)
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[0].element.opacity = 1
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[1].element.opacity = 1
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[1].element.text = strToNum
      pc.app.root.findByName("ObjectiveHolder").children[1].children[2].element.text = strToNum
  }
  else {
      pc.app.root.findByName("ObjectiveTime").parent.children[4].setLocalPosition(0, 10000, 0)
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[0].element.opacity = 1
      pc.app.root.findByName("ObjectiveTime").parent.children[4].children[1].element.opacity = 1
  }
}, 5);
;

function gameplayStuff() {

  pc.app.root.findByName("Game").findByName("Overlay").sound.slots["Headshot"].overlap = true

  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-1"
  ].volume = 0.5;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-2"
  ].volume = 0.5;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Jump-1"
  ].volume = 0.6;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Jump-2"
  ].volume = 0.6;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-2"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Grunt-3"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Lilium-Death-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Echo-Jump-1"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Echo-Jump-2"
  ].volume = 1;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-1"
  ].volume = 0.8;
  pc.app.root.findByName("Game").findByName("CharacterSound").sound.slots[
    "Shin-Jump-2"
  ].volume = 0.8;
  
  pc.app.root
      .findByName("Game")
      .findByName("UnlockItemReward").enabled = false;
  }